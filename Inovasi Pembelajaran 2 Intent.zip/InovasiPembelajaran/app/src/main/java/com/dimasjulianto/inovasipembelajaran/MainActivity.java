package com.dimasjulianto.inovasipembelajaran;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btTujuan = (Button) findViewById(R.id.bt_tujuan);
        Button btPemantik = (Button) findViewById(R.id.bt_pemantik);
        Button btKonsep = (Button) findViewById(R.id.bt_konsep);
        Button btMateri = (Button) findViewById(R.id.bt_materi);
        Button btTentang = (Button) findViewById(R.id.bt_tentang);

        btTujuan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this,TujuanActivity.class);
                startActivity(i);
            }
        });

        btPemantik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this,PemantikActivity.class);
                startActivity(i);
            }
        });

        btKonsep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this,KonsepActivity.class);
                startActivity(i);
            }
        });

        btMateri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this,MateriActivity.class);
                startActivity(i);
            }
        });

        btTentang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this,TentangActivity.class);
                startActivity(i);
            }
        });
    }
}